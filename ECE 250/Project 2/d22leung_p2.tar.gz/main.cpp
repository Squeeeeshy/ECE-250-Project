#include <iostream>
#include <string>
#include "TimeSeries.h"
#include "LinkedList.h"
#include "SingleCountry.h"
#include <fstream>



int main() {
    // Your code here


    bool alreadyCreated = false;

    SingleCountry *country = new SingleCountry("lab2_multidata.csv");

    std::string command;


    while(std::cin >> command){

        if(command == "LOAD"){

            if (alreadyCreated) {

                delete country; 
                country = new SingleCountry("lab2_multidata.csv");
            }
            
            alreadyCreated = true;

            std::string countryInput;
            std::cin >> countryInput;

            country->load(countryInput);

        }

        else if(command == "LIST"){

            country->list();
        }

        else if(command == "ADD"){

            std::string seriesCode;
            int year;
            double value;

            std::cin >> seriesCode >> year >> value;

           country->add(seriesCode, year, value);
           
        }

        else if(command == "UPDATE"){


            std::string seriesCode;
            int year;
            double value;

            std::cin >> seriesCode >> year >> value;

            country->update(seriesCode, year, value);

        }

        else if(command == "DELETE"){

           std::string seriesCode;

           std::cin >> seriesCode;

           country->remove(seriesCode);
        }

        else if(command == "BIGGEST"){

          country->biggest();
        }

        else if(command == "PRINT"){

          std::string seriesCode;

          std::cin >> seriesCode;

          country->print(seriesCode);
          
        }

        else if(command == "EXIT"){
          
          break;
        }

        else{

            std::cout << "invalid" << std::endl;
    
        }

    }


    delete country;
    country = nullptr;
    return 0;


}