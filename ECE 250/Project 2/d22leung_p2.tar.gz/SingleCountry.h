#include <iostream>
#include <string>


class SingleCountry{

    private:

        //private variables

        std::string file;




    public:

    //constructor
    SingleCountry(std::string fileName);


    //destructor
    ~SingleCountry();


    void load(std::string country);

    void list();

    void add(std::string seriesCode, int year, double data);

    void update(std::string seriesCode, int year, double data);

    void print(std::string seriesCode);

    void remove(std::string seriesCode);

    void biggest();





};


