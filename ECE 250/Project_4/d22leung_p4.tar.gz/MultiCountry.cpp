#include <iostream>
#include <string>
#include "SingleCountry.h"
#include <fstream>
#include "MultiCountry.h"
#include <cmath>




//constructor
MultiCountry::Node::Node(double minimum, double maximum, Node * L, Node * R) : mini(minimum), maxi(maximum), left(L), right(R){

    data = new std::string[512];
}

//destructor
MultiCountry::Node::~Node(){

    delete[] data;
    data = nullptr;
    delete left;
    delete right;
    left = nullptr;
    right = nullptr;

}



//sets the head to nullptr
MultiCountry::MultiCountry() : root(nullptr){


    for(int i = 0; i < 512; i++){

        all_country[i] = nullptr;
    }

}

//loads all the country's timeseries into the all_country array
void MultiCountry::load(std::string fileName){

    loadIndex(fileName);

    std::ifstream file(fileName);

    std::string line;

    //have two countryRead names to determine whether or not a new SingleCountry needs to be created
    std::string countryName1 = "";
    std::string countryName2 = "";

    std::string countryCodeRead = "";

    bool secondEntry = false;

    

    // 1. Go through the entire file

    while(std::getline(file, line)){   

        secondEntry = false;

        countryCodeRead = "";

        countryName1 = "";

        // 2. Finds the country of each time series
        for(int i = 0; i < line.length(); i++){

            if(secondEntry){

                if(line[i] == ','){

                    break;
                }

                countryCodeRead += line[i];
            }

            else{

                if(line[i] == ','){

                    secondEntry = true;
                    continue;
                }

                countryName1 += line[i];
            }
        }

       

        //if the next country is the same country, go to the next line
        if(countryName1 == countryName2){

            continue;
        }

       

        int index = getIndex(countryCodeRead);

        //if the country got removed first
        if(index == -1){

            continue;
        }

        all_country[index] = new SingleCountry(fileName);
        all_country[index]->load(countryName1);

        
        countryName2 = countryName1;
    
    }

    file.close();

    std::cout << "success" << std::endl;

}






void MultiCountry::list(std::string countryName){

    bool isValid = false;


    for(int i = 0; i < 512; i++){

        if(all_country[i] == nullptr){

            continue;
        }

        if(all_country[i]->country_name() == countryName){
        
            all_country[i]->list();
            isValid = true;
            break;
        }
    }

    if(!isValid){

        std::cout << "failure" << std::endl;
    }

    
}

void MultiCountry::test_print(){

    for(int i = 0; i < 512; i++){

        if(all_country[i] != nullptr){

            std::cout << all_country[i]->country_name() << std::endl;
        }

        if(all_country[i] == nullptr){

            std::cout << "EMPTY" << std::endl;
        }
    }

}

void MultiCountry::range(std::string seriesCode){

    double minimum;
    double maximum;

    bool firstOne = true;

    for(int i = 0; i < 512; i++){

        if(all_country[i] == nullptr){

            continue;
        }

        LinkedList<TimeSeries>::Node *ptr = all_country[i]->getCountryList()->getHead();

        while(ptr != nullptr){

            if(ptr->data->get_seriesCode() == seriesCode){

                break;
            }

            ptr = ptr->next;
        }

        if(ptr == nullptr){

            std::cout << "failure" << std::endl;
            return;
        }


        if(firstOne){

            minimum = ptr->data->mean();
            maximum = ptr->data->mean();

            firstOne = false;
        }

        else{

            if(ptr->data->mean() < minimum && ptr->data->isValid()){

                minimum = ptr->data->mean();
            }

            if(ptr->data->mean() > maximum && ptr->data->isValid()){

                maximum = ptr->data->mean();
            }
        }

        // std::cout << "The current mean is: " << ptr->data->mean() << " from: " << ptr->data->country << std::endl;
        // std::cout << "The updated min is: " << min << std::endl;
        // std::cout << "The update max is: " << max << std::endl;


    }

        

    std::cout << minimum << " " << maximum << std::endl;


}

void MultiCountry::setRange(std::string seriesCode){

    bool firstOne = true;

    for(int i = 0; i < 512; i++){

        if(all_country[i] == nullptr){

            continue;
        }

        LinkedList<TimeSeries>::Node *ptr = all_country[i]->getCountryList()->getHead();

        while(ptr != nullptr){

            if(ptr->data->get_seriesCode() == seriesCode){

                break;
            }

            ptr = ptr->next;
        }

        double meanValue = (ptr == nullptr) ? 0 : ptr->data->mean();

        if (firstOne) {

            min = meanValue;
            max = meanValue;
            firstOne = false;


        } else {


            min = std::min(min, meanValue);
            max = std::max(max, meanValue);

        }
        


    }

}

//the function called to build the binary tree
void MultiCountry::buildBinaryTree(std::string seriesCode){

    
    //destroy the existing tree if its already there
    if(hasTree){

        destroyTree(root);
    }

    int left_size = 0;
    int right_size = 0;
    std::string left_codes[512];
    std::string right_codes[512];

    hasTree = true;

    setRange(seriesCode);

    BTSeriesCode = seriesCode;

    root = new Node(min, max, nullptr, nullptr);

    double midpoint = (max + min) / 2;

    for(int i = 0; i < 512; i++){

        if(all_country[i] == nullptr || all_country[i]->getCountryList() == nullptr || all_country[i]->getCountryList()->getHead() == nullptr){

            continue;
        }

        LinkedList<TimeSeries>::Node *ptr = all_country[i]->getCountryList()->getHead();

        while(ptr != nullptr){

            if(ptr->data->get_seriesCode() == seriesCode){

                break;
            }

            ptr = ptr->next;
        }

        if(ptr == nullptr){

            continue;
        }

        
        root->data[i] = ptr->data->country;

        if(ptr->data->mean() < midpoint && ptr->data->mean() >= min){

            left_codes[left_size] = ptr->data->countryCode;
            left_size++;
        }

        else if(ptr->data->mean() >= midpoint && ptr->data->mean() <= max){

            right_codes[right_size] = ptr->data->countryCode;
            right_size++;
        }
        
    }

    

    root->left = buildSubTree(min, midpoint, seriesCode, true, left_codes, left_size);
    root->right = buildSubTree(midpoint, max, seriesCode, false, right_codes, right_size);

    std::cout << "success" << std::endl;

}

//the function called recursively to build the subsequent subtrees
MultiCountry::Node* MultiCountry::buildSubTree(double minimum, double maximum, std::string seriesCode, bool isLeft, std::string codes[], int size){

    Node *newNode = new Node(minimum, maximum, nullptr, nullptr);

    double newMin;
    double newMax;

    bool firstOne = true;


    //counts how many countries were added so I can put it in the correct index as well as to check if there's only one country left
    int j = 0;

    for(int i = 0; i < size; i++){

        //need to get hash index

        int index = getIndex(codes[i]);

        if(index == -1){

            continue;
        }

    
        if(all_country[index] == nullptr || all_country[index]->getCountryList() == nullptr || all_country[index]->getCountryList()->getHead() == nullptr){

            continue;
        }

        LinkedList<TimeSeries>::Node *ptr = all_country[index]->getCountryList()->getHead();

        while(ptr != nullptr){

            if(ptr->data->get_seriesCode() == seriesCode){

                break;
            }

            ptr = ptr->next;
        }

        if(ptr == nullptr){

            continue;
        }


        if(isLeft){

            //checks to see if its in the range
            if((ptr->data->mean() >= minimum) && (ptr->data->mean() < maximum)){

                newNode->data[j] = ptr->data->country;
                j++;

                if(firstOne){

                    newMax = ptr->data->mean();
                    newMin = ptr->data->mean();
                    firstOne = false;
                }

                else{

                    if(ptr->data->mean() > newMax){

                        newMax = ptr->data->mean();
                    }

                    if(ptr->data->mean() < newMin){

                        newMin = ptr->data->mean();
                    }
                }

                
            }
        }

        else if(!isLeft){

            //checks to see if its in the range
            if((ptr->data->mean() >= minimum) && (ptr->data->mean() <= maximum)){

                newNode->data[j] = ptr->data->country;
                       
                j++;

                if(firstOne){

                    newMax = ptr->data->mean();
                    newMin = ptr->data->mean();
                    firstOne = false;
                }

                else{

                    if(ptr->data->mean() > newMax){

                        newMax = ptr->data->mean();
                    }

                    if(ptr->data->mean() < newMin){

                        newMin = ptr->data->mean();
                    }
                }

            }
        }
        

    }

    //if there's only one country in the node
    if(j == 1){

        return newNode;
    }

    //if it happens to be empty just delete it
    if(j == 0){

        delete newNode;
        return nullptr;
    }
    

    if((newMax - newMin) < 1E-3 || newMax == newMin){

        return newNode;
    }

    double midpoint = (newMin + newMax) / 2;

    int left_size = 0;
    int right_size = 0;
    std::string left_codes[size];
    std::string right_codes[size];


    for(int i = 0; i < size; i++){

        //need to get hash index

        int index = getIndex(codes[i]);

        if(index == -1){

            continue;
        }

    
        if(all_country[index] == nullptr || all_country[index]->getCountryList() == nullptr || all_country[index]->getCountryList()->getHead() == nullptr){

            continue;
        }

        LinkedList<TimeSeries>::Node *ptr = all_country[index]->getCountryList()->getHead();

        while(ptr != nullptr){

            if(ptr->data->get_seriesCode() == seriesCode){

                break;
            }

            ptr = ptr->next;
        }

        if(ptr == nullptr){

            continue;
        }

        if(ptr->data->mean() < midpoint){

            left_codes[left_size] = codes[i];
            left_size++;
        }

        else if(ptr->data->mean() >= midpoint){

            right_codes[right_size] = codes[i];
            right_size++;
        }
        

    }

    newNode->left = buildSubTree(newMin, midpoint, seriesCode, true, left_codes, left_size);
    newNode->right = buildSubTree(midpoint, newMax, seriesCode, false, right_codes, right_size);

    return newNode;
}



void MultiCountry::printNode(Node *ptr){

    for(int i = 0; i < 512; i++){

        if(!ptr->data[i].empty()){

            std::cout << ptr->data[i] << " ";
            
        }
    }
}



void MultiCountry::find(double mean, std::string op){


    //theres no tree
    if(root == nullptr){

        std::cout << "failure" << std::endl;
        return;
    }

    //1. Equals
    if(op == "equal"){

        //arrPrint(mean, op);
        //return;

        //make a pointer to traverse the list
        MultiCountry::Node *ptr = root;

        double midpoint;

        double tolerance = 1E-3;

        while(ptr != nullptr){

            midpoint = (ptr->maxi + ptr->mini) / 2;

            if(((ptr->maxi - ptr->mini) < tolerance) && std::abs(mean - ptr->mini) < tolerance && std::abs(mean - ptr->maxi) < tolerance){
                
                printNode(ptr);
                break;
            }

            else if(mean < midpoint){

                ptr = ptr->left;
            }

            else if(mean >= midpoint){

                ptr = ptr->right;
            }

        }

        if(ptr == nullptr){

            std::cout << std::endl;
            return;
        }

        std::cout << std::endl;

    }

    //2. Less Than
    if(op == "less"){

        

        if(mean <= root->mini){

            std::cout << std::endl;
            return;
        }

        lessThan(root, mean);

        std::cout << std::endl;

    }

    //3. Greater Than
    if(op == "greater"){

        

        if(mean >= root->maxi){

            std::cout << std::endl;
            return;
        }

        greaterThan(root, mean);

        std::cout << std::endl;

    }

}




void MultiCountry::lessThan(Node* ptr, double mean){

    if(ptr == nullptr){

        return;
    }

    //base case: if the node's max < mean, print then return
    if(mean > ptr->maxi){

        printNode(ptr);
        return;
    }

    //if its less than the midpoint then go left
    double midpoint;
    midpoint = (ptr->maxi + ptr->mini) / 2;

    if(mean < midpoint){

        lessThan(ptr->left, mean);
    }

    //if its greater than the midpoint then split
    if(mean >= midpoint){

        lessThan(ptr->left, mean);
        lessThan(ptr->right, mean);
    }


    return;
}

void MultiCountry::greaterThan(Node *ptr, double mean){

    if(ptr == nullptr){

        return;
    }

    //base case: if the node's min > mean, print then return
    if(mean < ptr->mini){

        printNode(ptr);
        return;
    }

    //if its less than the midpoint then go left
    double midpoint;
    midpoint = (ptr->maxi + ptr->mini) / 2;


    //if its greater than the midpoint then go right
    if(mean >= midpoint){

        greaterThan(ptr->right, mean);
    }

    //if its less than that means i need to split
    if(mean < midpoint){

        greaterThan(ptr->left, mean);
        greaterThan(ptr->right, mean);
    }


    return;
}



void MultiCountry::deleteCountry(std::string countryName, bool calledFromRemove){

    //just checks to see if the tree and country exist
    if(root == nullptr){

        std::cout << "failure" << std::endl;
        return;
    }

    bool isValid = false;

    for(int i = 0; i < 512; i++){

        if(root->data[i] == countryName){

            isValid = true;
            break;
        }

    }

    if(!isValid && !calledFromRemove){

        std::cout << "failure" << std::endl;
        return;
    }

    if(!isValid && calledFromRemove){

        return;
    }

    MultiCountry::Node *parent = nullptr;
    MultiCountry::Node *ptr = root;

    double countryMean;

    for(int i = 0; i < 512; i++){

        if(all_country[i] == nullptr){

            continue;
        }

        if(all_country[i]->country_name() == countryName){

            LinkedList<TimeSeries>::Node *curr = all_country[i]->getCountryList()->getHead();

            while(curr != nullptr){

                if(curr->data->get_seriesCode() == BTSeriesCode){

                    countryMean = curr->data->mean();
                    break;
                }

                curr = curr->next;
            }

            //that means the time series does not exist for the country and thus is not in the tree
            if(curr == nullptr){

                std::cout << "failure" << std::endl;
                return;
            }

            break;
        }
    }

    deleteEmptyNodes(ptr, parent, countryName, countryMean);

    if(calledFromRemove){

        return;
    }
    std::cout << "success" << std::endl;
}






void MultiCountry::deleteEmptyNodes(Node* ptr, Node* parent, std::string countryName, double countryMean){

    if(ptr == nullptr){

        return;
    }

    
    //scans the current node for the target country, removes it
    for(int i = 0; i < 512; i++){

        if(ptr->data[i] == countryName){

            ptr->data[i] = "";
            break;
        }
    }

    double midpoint;

    midpoint = (ptr->maxi + ptr->mini) / 2;

    //checks if the node is empty
    bool isEmpty = true;

    for(int i = 0; i < 512; i++){

        if(ptr->data[i] != ""){

            isEmpty = false;
            break;
        }
    }


    //go do the same thing to the nodes to left/right
    if(countryMean < midpoint && ptr->left != nullptr){

        deleteEmptyNodes(ptr->left, ptr, countryName, countryMean);
    }

    else if(countryMean >= midpoint && ptr->right != nullptr){

        deleteEmptyNodes(ptr->right, ptr, countryName, countryMean);
    }

    //if the current node is empty with no children, then delete if after traversing the tree

    if(isEmpty && ptr->left == nullptr && ptr->right == nullptr){

        if(parent != nullptr){

            if(parent->left == ptr){

                parent->left = nullptr;
            }

            else if(parent->right == ptr){

                parent->right = nullptr;
            }

        }

        else{

            root = nullptr;
        }

        delete ptr;
    }

    
    return;
}




void MultiCountry::limits(std::string condition){

    if(root == nullptr){

        std::cout << "failure" << std::endl;
        return;
    }

    MultiCountry::Node *ptr = root;

    //1. Lowest

    if(condition == "lowest"){

        while(ptr != nullptr){

            if(ptr->left == nullptr && ptr->right == nullptr){

                printNode(ptr);
                break;
            }

            else if(ptr->left == nullptr && ptr->right != nullptr){

                ptr = ptr->right;
                continue;
            }

            ptr = ptr->left;
        }
    }

    //2. Highest

    if(condition == "highest"){

        while(ptr != nullptr){

            if(ptr->right == nullptr && ptr->left == nullptr){

                printNode(ptr);
                break;
            }

            else if(ptr->right == nullptr && ptr->left != nullptr){

                ptr = ptr->left;
                continue;
            }

            ptr = ptr->right;
        }
    }

    std::cout << std::endl;

}

void MultiCountry::destroyTree(Node* &ptr){

    //hit the end
    if(ptr == nullptr){

        return;
    }

    //post order traversal
    destroyTree(ptr->left);
    destroyTree(ptr->right);

    //passed by refernce to a pointer so that when i set ptr to nullptr the root is gonna be nullptr cause thats prolly the only thing going in there
    delete ptr;
    ptr = nullptr;

}

int MultiCountry::codeToW(std::string countryCode){

    int W = (countryCode[0] - 'A') * 676 + (countryCode[1] - 'A') * 26 + (countryCode[2] - 'A');

    return W;

}


int MultiCountry::primaryHash(int W){

    int hashCode = W % 512;

    return hashCode;

}

int MultiCountry::secondaryHash(int W){


    int hashCode;

    int x = static_cast<int>(floor(W / 512.0)) % 512;

    if(x % 2 == 0){

        hashCode = x + 1;
    }

    else{

        hashCode = x;
    }

    return hashCode;

}

void MultiCountry::hashFunction(std::string countryCode){

    int w = codeToW(countryCode);

    int i = 0;

    int m = 512;

    int index = (primaryHash(w)) % m;

    if(hashMap[index] == countryCode){

        return;
    }

    //if its occupied then keep probing
    while((!hashMap[index].empty()) && i < m){

        i++;
        index = (primaryHash(w) + i * secondaryHash(w)) % m;

        if(hashMap[index] == countryCode){

            return;
        }
    }

    if(i < m){
        
        hashMap[index] = countryCode;
    }

    else {

        std::cout << "Hash Table Full. Hopefully this doesn't show up." << std::endl;
    }
    
}

void MultiCountry::loadIndex(std::string fileName){

    std::ifstream file(fileName);

    std::string line;

    //have two countryRead names to determine whether or not a new SingleCountry needs to be created
    std::string countryCode1 = "";
    std::string countryCode2 = "";


    bool secondEntry;

    // 1. Go through the entire file

    while(std::getline(file, line)){   

        secondEntry = false;

        countryCode1 = "";

        // 2. Finds the country of each time series
        for(int i = 0; i < line.length(); i++){

            if(secondEntry){

                if(line[i] == ','){

                    break;
                }

                countryCode1 += line[i];

            }

            if(line[i] == ','){

                secondEntry = true;
            }   
            
        }

        //if the next country is the same country, go to the next line
        if(countryCode1 == countryCode2){

            continue;
        }

        else{

            hashFunction(countryCode1);

        }

        countryCode2 = countryCode1;

    }

    file.close();


}

void MultiCountry::lookup(std::string countryCode){

    int w = codeToW(countryCode);

    int i = 0;

    int steps = 1;

    int m = 512;

    int index = (primaryHash(w)) % m;

    

    if(hashMap[index] == countryCode){

        std::cout << "index " << index << " searches " << steps << std::endl;
        return;
    }

    else if(hashMap[index].empty()){

        std::cout << "failure" << std::endl;
        return;
    }

    while(i < m){

        i++;
        index = (primaryHash(w) + i * secondaryHash(w)) % m;
        steps++;

        //empty spot, I'll mark previously occupied spots w "-1"
        if(hashMap[index].empty()){

            break;
        }

        if(hashMap[index] == countryCode){

            std::cout << "index " << index << " searches " << steps <<  std::endl;

            return;
        }

    }


    std::cout << "failure" << std::endl;
       
    
}



void MultiCountry::remove(std::string countryCode){

    int w = codeToW(countryCode);

    int i = 0;

    int m = 512;

    int index = (primaryHash(w)) % m;

    if(hashMap[index] == countryCode){

        hashMap[index] = "-1";

        

        if(root != nullptr){

            deleteCountry(all_country[index]->country_name(), true);
        }

        delete all_country[index];

        all_country[index] = nullptr;


        std::cout << "success" << std::endl;
        return;
    }

    else if(hashMap[index].empty()){

        std::cout << "failure" << std::endl;
        return;
    }

    while(i < m){

        i++;

        index = (primaryHash(w) + i * secondaryHash(w)) % m;

        if(hashMap[index].empty()){

            std::cout << "failure" << std::endl;
            return;
        }

        if(hashMap[index] == countryCode){

            hashMap[index] = "-1";

            if(root != nullptr){

                deleteCountry(all_country[index]->country_name(), true);
            }

            delete all_country[index];

            all_country[index] = nullptr;


            std::cout << "success" << std::endl;
            return;
        }

    }

    std::cout << "failure" << std::endl;

}


int MultiCountry::getIndex(std::string countryCode){

    int w = codeToW(countryCode);

    int i = 0;

    int m = 512;

    int index = (primaryHash(w)) % m;

    if(hashMap[index] == countryCode){

        return index;
    }

    else if(hashMap[index].empty()){

        return -1;
    }

    while(i < m){

        i++;

        index = (primaryHash(w) + i * secondaryHash(w)) % m;

        if(hashMap[index].empty()){

            return -1;
        }

        if(hashMap[index] == countryCode){

            return index;
        }

    }

    // std::cout << "you mightve done goofed lmao" << std::endl; 
    return -1;

}


void MultiCountry::insert(std::string countryCode, std::string fileName){

    int w = codeToW(countryCode);

    int i = 0;

    int m = 512;

    int index = (primaryHash(w)) % m;

    bool found = false;

    if(hashMap[index].empty() || hashMap[index] == "-1"){

        hashMap[index] = countryCode;

        found = true;
    }

    else if(hashMap[index] == countryCode){

        std::cout << "failure" << std::endl;
        return;
    }

    while(i < m && !found){

        i++;

        index = (primaryHash(w) + i * secondaryHash(w)) % m;

        if(hashMap[index].empty() || hashMap[index] == "-1"){

            hashMap[index] = countryCode;
    
            found = true;

            break;
        }
    
        else if(hashMap[index] == countryCode){
    
            std::cout << "failure" << std::endl;
            return;
        }

    }

 
    

        std::ifstream file(fileName);

        std::string line;

        //have two countryRead names to determine whether or not a new SingleCountry needs to be created
        std::string countryName = "";
        std::string countryCodeRead = "";

        bool secondEntry = false;


        // 1. Go through the entire file

        while(std::getline(file, line)){   

            secondEntry = false;

            countryName = "";

            countryCodeRead = "";

            // 2. Finds the country of each time series
            for(int i = 0; i < line.length(); i++){

                if(secondEntry){

                    if(line[i] == ','){

                        break;
                    }

                    countryCodeRead += line[i];
                }

                else{

                    if(line[i] == ','){

                        secondEntry = true;
                        continue;
                    }

                    countryName += line[i];
                }
                
            }

            //if the next country is the same country, go to the next line
            if(countryCodeRead == countryCode){          

                all_country[index] = new SingleCountry(fileName);
                all_country[index]->load(countryName);

                

                break;
            }

            else{

                continue;
            }

        }

        file.close();

        


    

    
    std::cout << "success" << std::endl;

}


//destructor
MultiCountry::~MultiCountry() {

    for(int i = 0; i < 512; i++){

        delete all_country[i];
    }

    delete[] all_country; 
    destroyTree(root);


}


