#include <iostream>
#include <string>
#include "TimeSeries.h"
#include "LinkedList.h"
#include "SingleCountry.h"
#include "MultiCountry.h"
#include <fstream>



int main() {
    // Your code here

    
    MultiCountry * mc = new MultiCountry();
    

    // mc->loadIndex("test.txt");

    // mc->load("test.txt");



    
    //mc->load("test2.txt");



    // mc->loadIndex("lab2_multidata.csv");

    
    
    //mc->load("lab2_multidata.csv");

    //mc->test_print();
    
    
    std::string command;

    while(std::cin >> command){

        if(command == "LOAD"){

            std::string fileName;
            std::cin >> fileName;

            mc->load(fileName);

        }

        else if(command == "LIST"){

            std::string countryName;
            std::getline(std::cin >> std::ws, countryName);


            mc->list(countryName);
        }

        else if(command == "RANGE"){

            std::string seriesCode;
            std::cin >> seriesCode;

            mc->range(seriesCode);
           
        }

        else if(command == "BUILD"){


            std::string seriesCode;
            std::cin >> seriesCode;

            mc->buildBinaryTree(seriesCode);

        }

        else if(command == "FIND"){

           double mean;
           std::string operation;

           std::cin >> mean >> operation;

           mc->find(mean, operation);

        }

        else if(command == "DELETE"){
        
            std::string countryName;
        
            std::getline(std::cin >> std::ws, countryName);

            mc->deleteCountry(countryName, false);
        }

        else if(command == "LIMITS"){

          std::string condition;

          std::cin >> condition;

          mc->limits(condition);
          
        }

        else if(command == "LOOKUP"){

          std::string countryCode;

          std::cin >> countryCode;

          mc->lookup(countryCode);

        }

        else if(command == "REMOVE"){

            std::string countryCode;
  
            std::cin >> countryCode;
  
            mc->remove(countryCode);
  
          }

        else if(command == "INSERT"){

            std::string countryCode;

            std::string fileName;
  
            std::cin >> countryCode >> fileName;
  
            mc->insert(countryCode, fileName);
  
          }

        else if(command == "EXIT"){
          
          break;
        }

        else{

            std::cout << "invalid" << std::endl;
    
        }

    }



    delete mc;
    mc = nullptr;
    return 0;


}