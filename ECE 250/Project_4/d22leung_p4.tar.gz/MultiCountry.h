#include <iostream>
#include <string>
#include "SingleCountry.h"
#include <fstream>



class MultiCountry {
    
    public:

        class Node{

            public:

                //data and next
                std::string *data;
                int size;
                double mini;
                double maxi;
                Node *left;
                Node *right;

                
                //constructor
                Node(double minimum, double maximum, Node * L, Node * R);

                //destructor
                ~Node();

        };


        


        //head
        MultiCountry::Node * root;

        //512 sized array
        SingleCountry** all_country = new SingleCountry *[512];

        std::string hashMap[512];

        double max;
        double min;
        int numCountries;
        std::string BTSeriesCode;
        bool hasTree = false;
       
        

        //sets the head to nullptr
        MultiCountry();

        //loads all the country's timeseries into the all_country array
        void load(std::string fileName);
        

        void list(std::string countryName);

        void test_print();


        void range(std::string seriesCode);

        void setRange(std::string seriesCode);

        //the function called to build the binary tree
        void buildBinaryTree(std::string seriesCode);

        //the function called recursively to build the subsequent subtrees
        Node* buildSubTree(double minimum, double maximum, std::string seriesCode, bool isLeft, std::string codes[], int size);

        void printNode(Node *ptr);

        void find(double mean, std::string op);
    
        void lessThan(Node* ptr, double mean);

        void greaterThan(Node *ptr, double mean);

        


    
        void deleteCountry(std::string countryName, bool calledFromRemove);

           

        void deleteEmptyNodes(Node* ptr, Node* parent, std::string countryName, double countryMean);


        void limits(std::string condition);

        void destroyTree(Node* &ptr);
        
        int codeToW(std::string countryCode);

        int primaryHash(int W);

        int secondaryHash(int W);

        void hashFunction(std::string countryCode);
        
        void loadIndex(std::string fileName);

        void lookup(std::string countryCode);

        void remove(std::string countryCode);

        int getIndex(std::string countryCode);

        void insert(std::string countryCode, std::string fileName);



    //destructor
    ~MultiCountry();


};