#include <iostream>
#include <string>


class TimeSeries {

    public:

        //variables

        int* years;        
        double* data;

        int yearSize;      
        int dataSize; 

        int numYears;      
        int numData; 

        std::string country;
        std::string countryCode;

        std::string series;
        std::string seriesCode;
        
        
    //Constructor
    TimeSeries();


    //resize function
    void resize();

    bool load(std::string inputFile);

    bool print();

    bool add(int newYear, double newData);

    bool update(int newYear, double newData);

    double mean();

    bool is_monotonic();

    void best_fit(double &m, double &b);


    //destructor
    ~TimeSeries();

};