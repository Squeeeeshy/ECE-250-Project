#include <iostream>
#include <string>
#include "TimeSeries.h"



int main() {
    // Your code here

    TimeSeries ts;

    std::string command;


    while(std::cin >> command){

        if(command == "LOAD"){

            std::string filename;
            std::cin >> filename;

            if(ts.load(filename)){

                std::cout << "success" << std::endl;
            }   

            else{

                std::cout << "failure" << std::endl;
            }

            

        }

        else if(command == "PRINT"){

            ts.print();
        }

        else if(command == "ADD"){

            int year;
            double value;

            std::cin >> year >> value;

            if(ts.add(year, value)){


                std::cout << "success" << std::endl;
            }

            else{

                std::cout<< "failure" << std::endl;
            }

           
        }

        else if(command == "UPDATE"){

            int year;
            double value;

            std::cin >> year >> value;

            if(ts.update(year, value)){


                std::cout << "success" << std::endl;
            }

            else{

                std::cout<< "failure" << std::endl;
            }
        }

        else if(command == "MEAN"){

            if(ts.mean() != 0){


                std::cout << "mean is " << ts.mean()<< std::endl;
            }

            else{

                std::cout<< "failure" << std::endl;
            }
        }

        else if(command == "MONOTONIC"){

            if(ts.is_monotonic()){

                std::cout << "series is monotonic" << std::endl;
            }
        }

        else if(command == "FIT"){

            double m;
            double b;


            ts.best_fit(m, b);
        }

        else if(command == "EXIT"){
            
    
            break;
        }

        else{

            std::cout << "invalid" << std::endl;
            break;
        }


    }


  
    return 0;


}